import fetch from "node-fetch";

export default async function handler(req, res) {
  try {
    const { url, method = "GET", body, auth } = req.body;

    const headers = {
      "accept": "application/json",
      "user-agent": "3.49"
    };
    if (auth) headers["authorization"] = auth;

    const r = await fetch(url, {
      method,
      headers,
      body: body && body.length ? body : undefined
    });

    const txt = await r.text();
    try {
      res.status(200).json(JSON.parse(txt));
    } catch {
      res.status(200).send(txt);
    }
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
}
