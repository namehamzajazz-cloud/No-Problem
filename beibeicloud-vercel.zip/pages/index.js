import { useState } from "react";

export default function Home() {
  const [log, setLog] = useState("");
  const [running, setRunning] = useState(false);
  const [inviteCode, setInviteCode] = useState("");

  const appendLog = (msg) => setLog((prev) => prev + "> " + msg + "\n");

  async function startFlow() {
    setRunning(true);
    appendLog("Starting flow with invite code: " + inviteCode);

    try {
      const res = await fetch("/api/proxy", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          url: "https://api.beibeicloud.net/bby/activity/invite",
          method: "POST",
          body: JSON.stringify({ inviteCode }),
        }),
      });

      const data = await res.json();
      appendLog("Invite response: " + JSON.stringify(data));
    } catch (err) {
      appendLog("Error: " + err.message);
    }

    setRunning(false);
  }

  return (
    <div style={{ maxWidth: 800, margin: "40px auto", fontFamily: "sans-serif" }}>
      <h1>BeibeiCloud — Web Prototype</h1>

      <label style={{ display: "block", marginBottom: 8 }}>
        Invite Code:
        <input
          type="text"
          value={inviteCode}
          onChange={(e) => setInviteCode(e.target.value)}
          placeholder="Enter your invite code"
          style={{ display: "block", marginTop: 6, padding: 8, width: "100%" }}
        />
      </label>

      <button
        onClick={startFlow}
        disabled={running}
        style={{ padding: 10, background: "#2563eb", color: "#fff", border: "none", borderRadius: 6 }}
      >
        {running ? "Running..." : "Submit Invite"}
      </button>

      <pre
        style={{
          background: "#0f172a",
          color: "#e6eef8",
          padding: 12,
          borderRadius: 8,
          marginTop: 20,
          height: 300,
          overflow: "auto",
        }}
      >
        {log}
      </pre>
    </div>
  );
}